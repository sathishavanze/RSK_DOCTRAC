<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| CONFIG TYPES
| -------------------------------------------------------------------
| For keywords 
|
*/
$config['FieldsType'] = array(

'' => '', 

'text' => 'Text',

'checkbox' => 'Check Box',

'radio' => 'Radio',

'textarea' => 'Text Area',

'selectpicker' => 'Select Picker',

'select2picker' => 'Select 2 Picker'

 );

$config['keywords'] = array(
	'NewOrder' => '1',
	'PrescreenCompleted' => '10',
	'Pendingdocuments' => '15',
	'Alldocuments received' => '20',
	'WorkupCompleted' => '40',
	'Indexing Exception' => '43',
	'WaitingforConditional Approval' => '50',
	'OnHold' => '60',
	'UnderwriterCompleted' => '70',
	'SchedulingCompleted' => '80',
	'ClosingCompleted' => '90',
	'ClosedandBilled' => '100',
	'Cancelled' => '101'
);

$config['Workflows'] = [
	'PreScreen'=>'1',
	'WelcomeCall'=>'2',
	'TitleTeam'=>'3',
	'FHAVACaseTeam'=>'4',
	'ThirdPartyTeam'=>'5',
	'DocChase'=>'6',
	'Workup'=>'7',
	'UnderWriter'=>'8',
	'Scheduling'=>'9',
	'Closing'=>'10'
];

$config['ReverseWorkflows'] = [
	'WelcomeCall'=>2,
	'TitleTeam'=>3,
	'FHAVACaseTeam'=>4,
	'ThirdPartyTeam'=>5,
];

$config['ReverseAvailableWorkflows'] = [
	'Workup'=>7,
	'UnderWriter'=>8,
	'Scheduling'=>9,
	'Closing'=>10
];
$config['ReverseAvailableStatus'] = [
	'Alldocuments received' => 20,
	'WorkupCompleted' => 40,
	'UnderwriterCompleted' => 70,
	'SchedulingCompleted' => 80,
	'ClosingCompleted' => 90,
	'ClosedandBilled' => 100,

];
$config['NonAssignableWorkflows'] = [
		'DocChase'=>6,	
];

$config['OrderAssignWorkflows'] = [
	'TitleTeam'=>'3',
	'FHAVACaseTeam'=>'4',
	'ThirdPartyTeam'=>'5'
];

$config['OrderWorkflows'] = [
	'PreScreen'=>'1',
	'WelcomeCall'=>'2',
	'TitleTeam'=>'3',
	'FHAVACaseTeam'=>'4',
	'ThirdPartyTeam'=>'5'
];


$config['WorkflowStatus'] = [
	'Assigned' => 0,
	'InProgress' => 3,
	'Onhold' => 4,
	'Completed' => 5,
];


$config['DocumentCheckInEnabled'] = array(
	'New Order' => '1',
	'Waiting For Images' => '9',
	'Image Received' => '10'
);

$config['StackingEnabled'] = array(
	'New Order' => '1',
	'Waiting For Images' => '9',
	'Image Received' => '10',
	'Document CheckIn Completed' => '11',
	'Stacking In Progress' => '15'
);

$config['AuditEnabled'] = array(
	'New Order' => '1',
	'Waiting For Images' => '9',
	'Image Received' => '10',
	'Document CheckIn Completed' => '11',
	'Stacking In Progress' => '15',
	'Stacking Completed' => '16',
	'Audit In Progress' => '20',
);

$config['ReviewEnabled'] = array(
	'New Order' => '1',
	'Waiting For Images' => '9',
	'Image Received' => '10',
	'Document CheckIn Completed' => '11',
	'Stacking In Progress' => '15',
	'Stacking Completed' => '16',
	'Audit In Progress' => '20',
	'Audit Completed' => '23',
	'Review In Progress' => '29',
);

$config['ExportEnabled'] = array(
	'Export' => '40',
);

$config['ShippingEnabled'] = array(
	'Shipping' => '35',
);

$config['ExceptionEnabled'] = array(
	'Indexing Exception' => '43',
	'Indexing Exception Fix In Progress' => '44',
	'Fatal Exception' => '45',
	'Fatal Exception Fix In Progress' => '46',
	'Non Fatal Exception' => '47',
	'Non Fatal Exception Fix In Progress' => '48',

);





$config['OrderReverse'] = [

	10 => array(
		'Document CheckIn Completed' => '11',
	),

	11 => array(
		'Stacking Completed' => '16'
	),

	16 => array(
		'Audit In Progress' => '20',
	),
	
	23 => array(
		'Audit Completed' => '23',
		'Review In Progress' => '29',
		'Review Completed' => '30',
	),
	35 => array(
		'Shipping' => '35'
	),
	40 => array(
		'Export' => '40'
	),
	100 => array(
		'Draft In Progress' => '55',
		'Drafted' => '56',
		'On Hold' => '60',
		'Completed' => '100',
		'Cancelled' => '101'

	)

];

$config['SuperAccess'] = array(
	'Admin'=>1,
	'Supervisor'=>2,
);

$config['CustomerAccess'] = array(
	'Customer'=>4,
);

$config['AgentAccess'] = array(
	'Agent'=>3,
);

$config['BROWSER_DEFAULT_VERSION']=array(
					"IE"=>11.0,
					"Chrome"=>67.0,
					"Mozilla"=>61.0,
					"Safari"=>11.0,
					);
					
$config['BROWSERS']=array(
					"IE"=>['Name'=>'Internet Explorer',
						   'DefaultVersion'=>'11.0',
						   'link'=> "https://www.microsoft.com/en-in/download/Internet-Explorer-11-for-Windows-7-details.aspx"
						],
					"Chrome"=>['Name'=>'Chrome',
						   'DefaultVersion'=>'67.0',
						   'link'=> "https://www.google.com/chrome/"
						],
					"Mozilla"=>['Name'=>'Mozilla',
						   'DefaultVersion'=>'61.0',
						   'link'=> "https://www.mozilla.org/en-US/firefox/new/"
						],
					"Safari"=>['Name'=>'Safari',
						   'DefaultVersion'=>'11.0',
						   'link'=> "https://safari.en.softonic.com/"
						],
					);

$config['followupsType'] = array(
	'1' => 'Document Not Received',
	'2' => 'Audit Failed'
);

$config['DocTypes'] = [
1 => 'Security Instrument',
2 => 'Title Policy',
3 => 'Assignment',
4 => 'Deed',
5 => 'LGC',
6 => 'Other',
7 => 'CEMA',
];

$config['fund_date'] = ['0-30', '31-60', '61-90', '91-120', '121-150', '151-180', '>181'];

$config['pa_date'] = ['No %%Field%%', '0-30', '31-60', '61-90', '91-120', '121-150', '151-180', '>181'];

$config['pool_duedate'] = ['Delinquent', '0-30', '31-60', '61-90', '91-120', '121-150', '151-180', '>181'];

$config['Shipping_DueDate'] = ['No %%Field%%','0-30', '31-60', '61-90', '91-120', '121-150', '151-180', '>181'];

$config['ToDateRange'] = [

	'No %%Field%%' => " STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NULL ",
	'0-30' => "CASE WHEN STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NOT NULL THEN ABS(DATEDIFF(DATE(%%FieldName%%), DATE(%%AgeFieldName%%))) >= 0 ELSE FALSE END",
	'31-60' => "CASE WHEN STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NOT NULL THEN ABS(DATEDIFF(DATE(%%FieldName%%), DATE(%%AgeFieldName%%))) >= 31 ELSE FALSE END",
	'61-90' => "CASE WHEN STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NOT NULL THEN ABS(DATEDIFF(DATE(%%FieldName%%), DATE(%%AgeFieldName%%))) >= 61 ELSE FALSE END",
	'91-120' => "CASE WHEN STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NOT NULL THEN ABS(DATEDIFF(DATE(%%FieldName%%), DATE(%%AgeFieldName%%))) >= 91 ELSE FALSE END",
	'121-150' => "CASE WHEN STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NOT NULL THEN ABS(DATEDIFF(DATE(%%FieldName%%), DATE(%%AgeFieldName%%))) >= 121 ELSE FALSE END",
	'151-180' => "CASE WHEN STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NOT NULL THEN ABS(DATEDIFF(DATE(%%FieldName%%), DATE(%%AgeFieldName%%))) >= 151 ELSE FALSE END",
	'>181' => "CASE WHEN STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NOT NULL THEN ABS(DATEDIFF(DATE(%%FieldName%%), DATE(%%AgeFieldName%%))) > 180 ELSE FALSE END",
];

$config['FromDateRange'] = [

	'No %%Field%%' => " STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NULL ",
	'0-30' => "CASE WHEN STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NOT NULL THEN ABS(DATEDIFF(DATE(%%FieldName%%), DATE(%%AgeFieldName%%))) <= 30 ELSE FALSE END",
	'31-60' => "CASE WHEN STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NOT NULL THEN ABS(DATEDIFF(DATE(%%FieldName%%), DATE(%%AgeFieldName%%))) <= 60 ELSE FALSE END",
	'61-90' => "CASE WHEN STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NOT NULL THEN ABS(DATEDIFF(DATE(%%FieldName%%), DATE(%%AgeFieldName%%))) <= 90 ELSE FALSE END",
	'91-120' => "CASE WHEN STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NOT NULL THEN ABS(DATEDIFF(DATE(%%FieldName%%), DATE(%%AgeFieldName%%))) <= 120 ELSE FALSE END",
	'121-150' => "CASE WHEN STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NOT NULL THEN ABS(DATEDIFF(DATE(%%FieldName%%), DATE(%%AgeFieldName%%))) <= 150 ELSE FALSE END",
	'151-180' => "CASE WHEN STR_TO_DATE(%%FieldName%%, '%Y-%m-%d') IS NOT NULL THEN ABS(DATEDIFF(DATE(%%FieldName%%), DATE(%%AgeFieldName%%))) <= 180 ELSE FALSE END",
	'>181' => "",
];

$config['BarColor'] = [
	'rgba(68, 114,196,0.8)',
	'rgba(241, 140,85,0.8)',
	'rgba(80, 246,108,0.8)',
	'rgba(78, 208,248,0.8)',
	'rgba(236, 164,238,0.8)',
	'rgba(247, 9,9,0.8)',
	'rgba(0,255,0, 0.9)',
	'rgba(128,128,0, 0.8)',
	'rgba(255,0,255, 0.8)',

];


$config['Internal Roles'] = [
	'Admin' => 1,
	'Supervisor' => 2,
	'Agent' => 3
];

$config['Customer Roles'] = [
	'Customer' => 4,
];

$config['TPO Roles'] = [
	'TPO' => 5,
];

$config['Settlement Agent Roles'] = [
	'Settlement Agent' => 6,
];

$config['Investor Roles'] = [
	'Investor' => 7,
];

$config['Vendor Roles'] = [
	'Vendor' => 8,
];

$config['UploadPath'] = FCPATH . 'uploads/';

$config['MONTHS']=[ 'January','Febraury','March','April','May','June','July','August','September','October','November','December'];
// END OF FILE
